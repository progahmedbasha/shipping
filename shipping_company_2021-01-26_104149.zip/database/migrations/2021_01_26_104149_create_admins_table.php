<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateAdminsTable extends Migration {

	public function up()
	{
		Schema::create('admins', function(Blueprint $table) {
			$table->increments('id')->primary();
			$table->timestamps();
			$table->string('name', 100)->unique();
			$table->string('email', 100)->unique();
			$table->string('phone', 100)->unique();
		});
	}

	public function down()
	{
		Schema::drop('admins');
	}
}
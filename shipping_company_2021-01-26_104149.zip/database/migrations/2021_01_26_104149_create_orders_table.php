<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateOrdersTable extends Migration {

	public function up()
	{
		Schema::create('orders', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->integer('governorate_id')->unsigned();
			$table->integer('city_id')->unsigned();
			$table->integer('servant_id')->unsigned();
			$table->integer('shipping_price')->unsigned()->default('0');
			$table->integer('total_prices')->unsigned()->default('0');
		});
	}

	public function down()
	{
		Schema::drop('orders');
	}
}
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model 
{

    protected $table = 'products';
    public $timestamps = true;
    protected $fillable = array('sender_name', 'sender_phone', 'resever_name', 'resver_phone', 'governorate_id', 'city_id', 'adress', 'product_price', 'status_id', 'notes');

    public function governorates()
    {
        return $this->belongsTo('App\Models\Governorate', 'governorate_id');
    }

    public function cities()
    {
        return $this->belongsTo('App\Models\City', 'city_id');
    }

    public function status()
    {
        return $this->belongsTo('App\Models\Status', 'status_id');
    }

    public function ordersDetailes()
    {
        return $this->hasMany('App\Models\OrderDetailes');
    }

}
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model 
{

    protected $table = 'orders';
    public $timestamps = true;
    protected $fillable = array('governorate_id', 'city_id', 'servant_id', 'shipping_price', 'total_prices');

    public function servant()
    {
        return $this->belongsTo('App\Models\Servant', 'servant_id');
    }

    public function governorate()
    {
        return $this->belongsTo('App\Models\Governorate', 'governorate_id');
    }

    public function city()
    {
        return $this->belongsTo('App\Models\City', 'city_id');
    }

    public function ordersDetailes()
    {
        return $this->hasMany('App\Models\OrderDetailes');
    }

}
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderDetailes extends Model 
{

    protected $table = 'order_detailes';
    public $timestamps = true;
    protected $fillable = array('product_id', 'sender_name', 'sender_phone', 'resever_name', 'resver_phone', 'adress', 'product_price', 'order_id', 'product_status', 'notes');

    public function product()
    {
        return $this->belongsTo('App\Models\Product', 'project_id');
    }

    public function order()
    {
        return $this->belongsTo('App\Models\Order', 'order_id');
    }

}